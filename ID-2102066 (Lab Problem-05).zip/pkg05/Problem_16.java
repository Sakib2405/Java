/*
  Write a Java program to check if a string starts with a specified word.
Sample Data: string1 = "Hello how are you?"
Sample Output:

true
 */
package labproble.pkg05;
 public class Problem_16 {
 public static void main(String[] args)
 {
   String string1 = "Hello how are you?";
    System.out.println(string1.startsWith("Hello"));
  }
}

