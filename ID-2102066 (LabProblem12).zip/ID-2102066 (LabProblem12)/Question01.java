package LabProblem12;

public class Question01 {
    public static void main(String[] args) {
       
        String name = "Java Exarcises!";
        int index1 = name.charAt(0);
        int index2 = name.charAt(10);
        System.out.println("The character at position 0 is "+(char)index1);
        System.out.println("The character at position 10 is "+(char)index2);
    }
}
