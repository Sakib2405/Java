package LabProblem12;

public class Question28 {
    public static void main(String[] args) {
        
        String str = "Java Exercises.";
        char[] arr = str.toCharArray();
        System.out.println(arr);
    }
}
