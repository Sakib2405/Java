package LabProblem12;

public class Question04 {
    public static void main(String[] args) {
        
        String name = "w3rsource.com";
        System.out.println("Original String : "+name);
        int num = name.codePointCount(1, 10);
        System.out.println("CodePoint count : "+num);
    }
}
