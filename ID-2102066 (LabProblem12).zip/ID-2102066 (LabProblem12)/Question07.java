package LabProblem12;

public class Question07 {
    public static void main(String[] args) {
       
        String str1 = "PHP Exercises and ";
        String str2 = "Python Exercises";
        System.out.println("String1 : "+str1);
        System.out.println("String2 : "+str2);
        String str = str1.concat(str2);
        System.out.println(str);
    }
}
