/*
 Write a Java program to print the ASCII value of a given character.
Expected Output

The ASCII value of Z is :90
 */
package labproblem;

public class Problem_10 {

	public static void main(String[] String) {
		int chr = 'Z';
		System.out.println("The ASCII value of Z is :"+chr);
	}
}



