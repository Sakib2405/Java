/*
 Write a Java program to display the current date and time in a specific format.
Sample Output:

Now: 2017/06/16 08:52:03.066
 */
package labproblem;

 import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class Problem_16 {

	public static void main(String args[]) {
		SimpleDateFormat cdt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
		cdt.setCalendar(Calendar.getInstance(TimeZone.getTimeZone("GMT")));
		
		System.out.println("\nNow: "+cdt.format(System.currentTimeMillis()));
	}
}



