/*
 Write a Java program to display system time.
Sample Output:

Current Date time: Fri Jun 16 14:17:40 IST 2017 
 */
package labproblem;

public class Problem_15{
  
  public static void main(String[] args){
         System.out.format("\nCurrent Date time: %tc%n\n", System.currentTimeMillis());
    }
}

