/*
  Write a Java program to extract the first half of a even string.
Test Data: Python
Sample Output:
Pyt
 */
package labproblem.pkg04;
 public class Problem_19 {
 public static void main(String[] args)
 {
    String main_string = "Python";    
    System.out.println(main_string.substring(0, main_string.length()/2));	
  } 
 }


