/*
  Write a Java program to accept an integer and count the factors of the number.
Sample Output:

Input an integer: 25                                                   
3
 */
package labproblem.pkg04;

import java.util.*;
 public class Problem_07 {
     public static void main(String[] args){
      Scanner in = new Scanner(System.in);
      System.out.print("Input an integer: ");
      int x = in.nextInt(); 

		System.out.println(result(x));
	 } 		
	public static int result(int num) {	
		int ctr = 0;
        for(int i=1; i<=(int)Math.sqrt(num); i++) {
            if(num%i==0 && i*i!=num) {
                ctr+=2;
            } else if (i*i==num) {
                ctr++;
            }
        }
        return ctr;
	}
 }

