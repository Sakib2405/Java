/*
  Write a Java program to create an array from a given array of integers. The newly created array will contain the elements from the given array before the last element value of 10. 
 */
package labproblem.pkg06;


import java.util.*; 
 public class Exercise_04 {
 public static void main(String[] args)
 {
	int[] array_nums = {11, 15, 13, 10, 45, 20, 33, 53};
	System.out.println("Original Array: "+Arrays.toString(array_nums)); 
	
	int l = 0;
	int[] new_array;
	while(array_nums[l] != 10)
	  l++;
	new_array = new int[l];
     System.arraycopy(array_nums, 0, new_array, 0, l);
	System.out.println("New Array: "+Arrays.toString(new_array)); 
  }
}
