/*
  Write a Java program to create an array from a given array of integers. The newly created array will contain elements from the given array after the last element value is 10.
 */
package labproblem.pkg06;
import java.util.*; 
 public class Exercise_03 {
 public static void main(String[] args)
 {
	int[] array_nums = {11, 10, 13, 10, 45, 20, 33, 53};
	System.out.println("Original Array: "+Arrays.toString(array_nums)); 
	
	int l = array_nums.length - 1;
	int[] new_array;
	while(array_nums[l] != 10)
		l--;
	new_array = new int[array_nums.length - 1 - l];
	for(int i = l + 1; i < array_nums.length; i++)
		new_array[i - l - 1] = array_nums[i];
	System.out.println("New Array: "+Arrays.toString(new_array)); 
  }
}



